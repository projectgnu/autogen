/* -*- buffer-read-only: t -*- vi: set ro:
 *
 * Prototypes for columns
 * Generated Fri Jul 24 18:46:52 PDT 2015
 */
#ifndef COLUMNS_PROTO_H_GUARD
#define COLUMNS_PROTO_H_GUARD 1

#endif /* COLUMNS_PROTO_H_GUARD */
